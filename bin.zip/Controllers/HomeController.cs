﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication9.Models;

namespace WebApplication9.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        studentcontext s = new studentcontext();
        public ActionResult Index()
        {
            var r = s.students.ToList();
            return View(r);
        }

        [HttpGet]

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]

        public ActionResult Create(student i)
        {
            if (ModelState.IsValid == true)
            {
                
                
                
               
                s.students.Add(i);
                int k = s.SaveChanges();
                if (k > 0)
                {
                    ViewData["x"] = "<script>alert('Recored Save!!!!')</script>";
                 
                 
                    Response.Redirect("Index");
                }

            }
            else
            {
                ViewData["x"] = "<script>alert('Please Insert Data!!!!')</script>";
            }
            return View();
        }

        /* Edit Operation Start !!!!!!!!!!!!!!!*/

        /* Edit Operation Start !!!!!!!!!!!!!!!*/

        [HttpGet]
        public ActionResult Edit(int id)
        {
            var t = s.students.Where(model => model.Id == id).FirstOrDefault();
            return View(t);
        }

        [HttpPost]
        public ActionResult Edit(student su)
        {
            s.Entry(su).State = System.Data.Entity.EntityState.Modified;
            s.SaveChanges();


            ViewData["x"] = "<script>alert('Update Sucessfully!!!!')</script>";


            return RedirectToAction("Index");
        }
        /* Edit Operation End ************* */
        /* Delete Operation Start !!!!!!!!!!!!!!!!*/
        [HttpGet]
        public ActionResult Delete(int id)
        {
            var t = s.students.Where(model => model.Id == id).FirstOrDefault();
            return View(t);
        }
        [HttpPost]
        public ActionResult Delete(student d)
        {
            s.Entry(d).State = System.Data.Entity.EntityState.Deleted;
            s.SaveChanges();

            return RedirectToAction("Index");

        }
        /* Delete Operation End *************/

        /* Details Operation Start !!!!!!!!!!!!!!!!*/
        [HttpGet]
        public ActionResult Details(int id)
        {
            var t = s.students.Where(model => model.Id == id).FirstOrDefault();
            return View(t);
        }


        
    }
}